import 'package:flutter/material.dart';

class CustomMessageTile extends StatelessWidget {
  const CustomMessageTile({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
