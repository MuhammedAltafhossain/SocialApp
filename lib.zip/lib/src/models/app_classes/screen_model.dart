import 'package:flutter/widgets.dart';

class ScreenModel {
  Widget page;
  String? label;
  IconData? icons;

  ScreenModel({required this.page, this.label, this.icons});
}
