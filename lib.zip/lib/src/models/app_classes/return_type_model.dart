class ReturnType<T> {
  T? value;
  bool isValid;
  ReturnType({
    this.value,
    required this.isValid,
  });
}
