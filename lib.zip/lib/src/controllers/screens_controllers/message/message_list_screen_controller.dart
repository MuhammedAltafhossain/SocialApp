import 'package:get/get.dart';
import 'package:social_app/src/models/pojo_classes/message_model.dart';

class MessageListScreenController extends GetxController {
  RxList<String> messageList = RxList([
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
  ]);
}
