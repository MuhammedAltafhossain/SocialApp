import 'package:get/get.dart';

class MessageListScreenController extends GetxController {
  RxList<String> messageList = RxList([
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
    "sasasasdwfedsdsdcdv",
    "asasjdudeucucnucucu",
  ]);
}
