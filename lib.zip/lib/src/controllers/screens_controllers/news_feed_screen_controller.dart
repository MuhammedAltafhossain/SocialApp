import 'package:get/get.dart';

class NewsFeedScreenController extends GetxController {}
