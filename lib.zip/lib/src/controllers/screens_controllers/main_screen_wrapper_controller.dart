import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:social_app/component.dart';
import 'package:social_app/src/controllers/data_controllers/data_controller.dart';
import 'package:social_app/src/screens/screens/intro_screen.dart';
import 'package:social_app/src/screens/screens/main_screen_wrapper.dart';
import 'package:social_app/src/screens/screens/user/signIn_screen.dart';

class MainScreenWrapperController extends GetxController {
  final DataController _dataController = Get.find();
  RxBool isInitApp = false.obs;
  final PageController pageController = PageController();

  List<Widget> pages = [
    Container(color: defaultWhite, child: const SafeArea(child: Center(child: CircularProgressIndicator(color: primarySwatch)))),
    IntroPage(),
    SignInPage(),
    MainScreenWrapper(),
  ];

  @override
  void onInit() {
    super.onInit();
    _dataController.initApp().then((_) {
      isInitApp.value = true;
      _movePage();
    });

    _dataController.user.listen((_) => _movePage());
    _dataController.appData.listen((_) => _movePage());

    _dataController.appData.value = _dataController.appData.value.copyWith(showOnBoardScreen: true); //! For test
  }

  _movePage() {
    print(_dataController.appData.value.toString());
    if (isInitApp.value) {
      // when logout
      if (_dataController.user.value == null) {
        // When showOnBoardScreen = true
        if (_dataController.appData.value.showOnBoardScreen) {
          if (kDebugMode) print("(Listener) MainScreenWrapperController: Moving to IntroPage");
          pageController.animateToPage(
            1,
            duration: const Duration(milliseconds: defaultDuration),
            curve: Curves.linear,
          );
        } else {
          if (kDebugMode) print("(Listener) MainScreenWrapperController: Moving to SignInPage");
          pageController.animateToPage(
            2,
            duration: const Duration(milliseconds: defaultDuration),
            curve: Curves.linear,
          );
        }
      } else {
        if (kDebugMode) print("(Listener) MainScreenWrapperController: Moving to MainScreenWrapper");
        pageController.animateToPage(
          3,
          duration: const Duration(milliseconds: defaultDuration),
          curve: Curves.linear,
        );
      }
    }
  }
}
