import 'package:get/get.dart';

class NotificationScreenController extends GetxController {}
