import 'package:get/get.dart';

class FollowerScreenController extends GetxController {}
